package com.example.geoschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
    }
    public void irruta(View v) {

        Intent intent= new Intent(getApplicationContext(), Ruta.class);
        startActivity(intent);

    }
    public void irnotificacion(View v) {

        Intent intent= new Intent(getApplicationContext(), Notificaciones.class);
        startActivity(intent);

    }
    public void irchat(View v) {

        Intent intent= new Intent(getApplicationContext(), Chat.class);
        startActivity(intent);

    }
}